# Webstack monitoring

This project invovled setting up Sumo Logic accounts to monitor server traffic
on my three HBnB servers.

## Tasks :page_with_curl:

* **0. Monitor your Nginx traffic**
  * [0-monitor_your_nginx_traffic](./0-monitor_your_nginx_traffic): Text file containing
  my Sumo Logic access key.
    * First line: `Access ID`
    * Second line: `Access Key`

* **1. Monitor your server**
  * For this task, I configured Sumo Logic to monitor my server's memory, CPU, network
  and disk.
