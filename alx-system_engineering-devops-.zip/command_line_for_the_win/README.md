# Command Line For The Win

These are screenshots from my progress in the [CMDCHALLENGE](https://cmdchallenge.com/). 

CMD CHALLENGE is a pretty cool game challenging you on Bash skills. Everything is done via the command line and the questions are becoming increasingly complicated. It’s a good training to improve your command line skills!

This repository contains projects from all three categories of the command-line challenge:
- The [cmdchallenge](https://cmdchallenge.com/) with 42 tasks
- The [oops.cmdchallenge](https://oops.cmdchallenge.com/) with 5 tasks
- and The [12days.cmdchallenge](https://12days.cmdchallenge.com/) with 12 tasks


I have provided the screenshots both in .png and .jpg format
